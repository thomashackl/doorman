# Doorman
Some courses may require automatic changing of access rules some time before their first date, e.g. set binding admission, removing the waiting list or stopping automatic moving up of waiting list members.
